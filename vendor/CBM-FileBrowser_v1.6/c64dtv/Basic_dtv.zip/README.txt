Selecting this from typical C64DTV menus will go to BASIC.

The magic is not in dummy_dtv.dtv but in the index.txt
start address which is 58260=$E394=BASIC Cold Start.
